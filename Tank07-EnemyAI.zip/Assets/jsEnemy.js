#pragma strict
private var power = 1200; // 포탄발사속도에욤

var bullet :Transform; // 포탄선언
var target :Transform; //목표
var spPoint :Transform; //스폰포인트
var explosion :Transform; //폭구앞의화염
var snd : AudioClip;//발사음
function Start () {

}

function Update () {
	transform.LookAt(target); // 아군방향으로회전시키는

}