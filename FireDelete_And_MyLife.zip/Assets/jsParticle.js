#pragma strict

function Start () {
	
}

function Update () {
	Destroy(gameObject,3);
	
}