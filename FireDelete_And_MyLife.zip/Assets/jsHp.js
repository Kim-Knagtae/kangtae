#pragma strict

	public  var MaxHealth : int = 100;
	static var CurrentHealth : int = 100;
	
	public var  HealthBarLength : float;
function Start () {
	HealthBarLength = Screen.width / 2;
}

function Update () {
	Debug.Log("CurrentHealth ="+CurrentHealth);
	if(CurrentHealth < 1){
		Application.LoadLevel(0);
}
}

function OnGUI() {
if(CurrentHealth < 0) {
			CurrentHealth = 0;
		} else if(MaxHealth < CurrentHealth) {
			CurrentHealth = MaxHealth;	
		}
		 // GUI.Box(Rect(0,0,Screen.width,Screen.height),"This is a title");
		GUI.Box (Rect(10, 10, HealthBarLength / (MaxHealth / CurrentHealth), 20), CurrentHealth + "/" + MaxHealth);
	}



	
	