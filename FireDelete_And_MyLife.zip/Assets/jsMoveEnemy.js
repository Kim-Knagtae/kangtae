#pragma strict

var rotAng = 15;

var NextPos : Vector3;

var m_speed : float;

function Start () {

	NextMove();

}

function Update () {
	//var amtToRot = rotAng * Time.deltaTime;
	//transform.RotateAround(Vector3.zero, Vector3.up, amtToRot);
	
	transform.position = Vector3.MoveTowards(transform.position, NextPos, m_speed); 
		
	if(transform.position == NextPos) 	 NextMove();
	

}

function NextMove () {

	var rx = Random.Range(-40,40);
	var rz = Random.Range(-40,40);
	
	NextPos = new Vector3 (rx, 0, rz);
	
	transform.rotation = Quaternion.LookRotation(NextPos - transform.position);

	
	
	
	Debug.Log(""+rx);
	Debug.Log(""+rz);	
	
}