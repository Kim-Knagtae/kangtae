#pragma strict
private var power = 1200; // 포탄발사속도에욤

var bullet :Transform; // 포탄선언
var target :Transform; //목표
var spPoint :Transform; //스폰포인트
var explosion :Transform; //폭구앞의화염
var snd : AudioClip;//발사음
function Start () {

}

function Update () {
	transform.LookAt(target); // 아군방향으로회전시키는
	var hit: RaycastHit;
//	var fwd = Vector3.forward;
//	var fwd = transform.TransformDirection(Vector3.forward);
	var fwd = transform.TransformDirection(Vector3.forward);
	if(Physics.Raycast(spPoint.transform.position, fwd, hit, 20)==false) return;
	
	Instantiate(explosion, spPoint.transform.position, Quaternion.identity);
	
	var obj=Instantiate(bullet, spPoint.transform.position, Quaternion.identity);
	obj.rigidbody.AddForce(fwd*power);
	
	AudioSource.PlayClipAtPoint(snd, spPoint.transform.position);
	
}