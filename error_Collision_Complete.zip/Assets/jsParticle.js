#pragma strict

function Start () {
	Destroy(gameObject.Find("pfExplosion"),3);
	Destroy(gameObject.Find("pfExplosion2"),3);
}

function Update () {

}