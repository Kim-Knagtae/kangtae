#pragma strict

static var hit = 0;

static var lose = 0;

function OnGUI(){

	GUI.Label(Rect(10,10,120,20),"명중: "+hit);
	GUI.Label(Rect(10,30,120,20),"피격: "+lose);
	}
function Start () {

}

function Update () {

}