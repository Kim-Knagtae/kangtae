 using UnityEngine;
 using System.Collections;

 public class csBullet : MonoBehaviour 
 {
     public AudioClip snd;
     public Transform explosion;
 
     void OnTriggerEnter (Collider coll)
     {
         if (coll.gameObject.tag == "WALL")
         {
             Instantiate (explosion, coll.transform.position, Quaternion.identity);
             AudioSource.PlayClipAtPoint (snd, transform.position);
             Destroy (coll.gameObject);
             Destroy (gameObject);
         }
     }
 }


