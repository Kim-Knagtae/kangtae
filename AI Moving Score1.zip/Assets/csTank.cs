using UnityEngine;
 using System.Collections;
 
 public class csTank : MonoBehaviour 
 {
     public float speed = 5.0f;   // moving speed
     public float rotSpeed = 120.0f; // rotation speed
     public GameObject turret;  // tank turret object
 
     public int power = 2000;  // bullet speed power
     public Transform bullet;  // bullet object
 
     void Update () 
     {
         float amtToMove = speed * Time.deltaTime; // moving distance per frame
         float amtToRot = rotSpeed * Time.deltaTime; // rotation angle per frame
  
         float front = Input.GetAxis ("Vertical"); // moving front/back
         float ang = Input.GetAxis ("Horizontal"); // moving left/right
         float ang2 = Input.GetAxis ("MyTank");  // moving turret
 
         transform.Translate (Vector3.forward*-1 * front * amtToMove); // moving front/back
         transform.Rotate (Vector3.up * ang * amtToRot);    // moving left/right
         turret.transform.Rotate (Vector3.up * ang2 * amtToRot);  // moving turret

         if (Input.GetButtonDown ("Fire1"))
 {
     GameObject spPoint = GameObject.Find ("TankSpawnPoint");
     Transform myBullet = (Transform)Instantiate (bullet, spPoint.transform.position, spPoint.transform.rotation);
     myBullet.rigidbody.AddForce (spPoint.transform.forward * power);
 }
     }
}
