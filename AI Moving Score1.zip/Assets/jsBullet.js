#pragma strict

var snd : AudioClip;

var explosion : Transform;

function OnTriggerEnter(coll : Collider){

			Instantiate(explosion,coll.transform.position, Quaternion.identity);
            AudioSource.PlayClipAtPoint (snd, transform.position);
          
            Destroy (gameObject);  
             
            if (coll.gameObject.tag == "WALL"){
            jsScore.hit++;
            Destroy(coll.transform.root.gameObject);	
            } else if (coll.gameObject.tag == "ENEMY"){
            jsScore.hit++;
            if(jsScore.hit>5){
            Destroy(coll.transform.root.gameObject);
            }
             
            }else if(coll.gameObject.tag == "TANK"){
             jsScore.lose++;
             if(jsScore.lose>5){
             }
            }
        }

function Start () {

}

function Update () {

}