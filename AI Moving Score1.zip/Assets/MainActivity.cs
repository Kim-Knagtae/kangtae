using UnityEngine;
using System.Collections;

public class MainActivity : MonoBehaviour {
	public Texture texture_start;
	public Texture texture_end;
	
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	
	void OnGUI(){
		if(GUI.Button (new Rect(Screen.width*3/7,Screen.height*3/7,Screen.width*1/7,Screen.height*1/7),texture_start)){
			Application.LoadLevel(1);
		}
		if(GUI.Button (new Rect(Screen.width*3/7,Screen.height*5/7,Screen.width*1/7,Screen.height*1),texture_start)){
			Application.Quit();
		}
	}
}
