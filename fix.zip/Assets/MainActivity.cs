using UnityEngine;
using System.Collections;

public class MainActivity : MonoBehaviour {
	public Texture texture_Main;
	public Texture texture_Level1;
	public Texture texture_Level2;
	public Texture texture_Level3;
	
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	
	void OnGUI(){
		if(GUI.Button (new Rect(Screen.width*5/12,Screen.height*1/7,Screen.width*1/7,Screen.height*1/6),texture_Level1)){
			Application.LoadLevel(1);
		}
		if(GUI.Button (new Rect(Screen.width*5/12,Screen.height*3/7,Screen.width*1/7,Screen.height*1/6),texture_Level2)){
			Application.LoadLevel(2);
		}
		if(GUI.Button (new Rect(Screen.width*5/12,Screen.height*5/7,Screen.width*1/7,Screen.height*1/6),texture_Level3)){
			Application.LoadLevel(3);
		}
	}
}
