#pragma strict

var Enemy : GameObject[];

function Start () {
	
}

function Update () {
	Enemy = GameObject.FindGameObjectsWithTag("ENEMY"); 
	if(Enemy.Length == 0){
		Application.LoadLevel(0);
	}

}