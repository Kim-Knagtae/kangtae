#pragma strict

var snd : AudioClip;

function Start () {

}

function Update () {

}