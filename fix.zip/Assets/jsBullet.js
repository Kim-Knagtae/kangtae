#pragma strict

var snd : AudioClip;

var explosion : Transform;

function OnTriggerEnter(coll : Collider){

			Instantiate(explosion,coll.transform.position, Quaternion.identity);
            AudioSource.PlayClipAtPoint (snd, transform.position);
          
            Destroy (gameObject);  
             
        
            
            if(coll.gameObject.tag == "ENEMY"){
            jsScore.hit++;
            Destroy(coll.transform.root.gameObject);
            }
           
           if(coll.gameObject.tag == "TANK"){
             jsHp.CurrentHealth -= 20;
             jsScore.lose++;
          
            }
        }

function Start () {

}

function Update () {

}